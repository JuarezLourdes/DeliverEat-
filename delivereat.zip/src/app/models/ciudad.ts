export class Ciudad {
  Id: number;
  Nombre: string;
}
export const Ciudades: Ciudad[] = [
  {Id: 1, Nombre: "Córdoba" },
  {Id: 2, Nombre: "Villa Allende"},
  {Id:3,Nombre: "Rio Ceballos" },
]